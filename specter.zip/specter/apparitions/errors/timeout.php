<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Session Timeout</title>
    </head>
    <body>
        <h1>Session Timeout</h1>
        <p>Your session timed out due to inactivity.</p>
        <p>Please go <a href="javascript:history.back(1)">back</a> and try again.</p>
    </body>
</html>
