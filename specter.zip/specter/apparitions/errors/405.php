<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
            <title>405 Not Found</title>
    </head>
    <body>
        <h1>Method Not Allowed</h1>
        <p>The requested resource dose not support this method.</p>
        <p>Please go <a href="javascript:history.back(1)">back</a> and try again.</p>
    </body>
</html>
