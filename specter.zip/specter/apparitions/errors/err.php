<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Error</title>
    </head>
    <body>
        <h1>Error</h1>
        <p><b>Error</b> [<?=$no?>] on line <?=$line?> in <?=$file?>. <?=$str?></p>
        <p>Please go <a href="javascript:history.back(1)">back</a> and try again.</p>
    </body>
</html>
