<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>404 Not Found</title>
    </head>
    <body>
        <h1>Not Found</h1>
        <p>The requested URL was not found on this server.</p>
        <p>Please go <a href="javascript:history.back(1)">back</a> and try again.</p>
    </body>
</html>
