<?php
return function(\FastRoute\RouteCollector $r) {
};
